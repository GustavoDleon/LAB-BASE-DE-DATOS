
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

@if ($errors->any())
<div class="alert alert-danger">
    <ul>
        @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
</div>
@endif
<div class="container">
    <br>
    <br>
    <form class="form-horizontal col-sm-12" action="/menu/{{$menu->id}}" method="post" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <h1>Editar platillo</h1>
        <div class="form-group row">
            <label for="text" class="col-4 col-form-label">Nombre del platillo </label>
            <div class="col-8">
                <input id="name" name="name" type="text" value="{{$menu->name}}" class="form-control" required="required">
            </div>
        </div>
            <div class="form-group row">
                    <label for="text" class="col-4 col-form-label">Descripcion del platillo</label>
                    <div class="col-8">
                        <input id="description" name="description" type="text" value="{{$menu->description}}" class="form-control" required="required">
                    </div>
            </div>
                    <div class="form-group row">
                            <label for="text" class="col-4 col-form-label">Precio</label>
                            <div class="col-8">
                                <input id="price" name="price" type="text" value="{{$menu->price}}" class="form-control" required="required">
                            </div>
        </div>
        <div class="form-group row">
            <div class="offset-4 col-8">
                <button name="submit" type="submit" class="btn btn-primary">Guardar</button>

            </div>

        </div>
    </form>
</div>
