
<style>
        table {
          font-family: arial, sans-serif;
          border-collapse: collapse;
          width: 100%;
        }
        
        td, th {
          border: 1px solid #dddddd;
          text-align: left;
          padding: 8px;
        }
        
        tr:nth-child(even) {
          background-color: #dddddd;
        }
        </style>
  
<div class="container">
    <br>
    <br>
        <div class="row">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre del platillo </th>
                        <th scope="col">Descripcion</th>
                        <th scope="col">Precio</th>
                        <th>Editar</th>
                        <th>Eliminar</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($allMenus as $area)
                    <tr>
                        <td>{{$area->id}}</td>
                        <td>
                            <a  class="btn btn-link " role="button"> {{$area->name}}</a>
                        </td>
                        <td>
                                <a  class="btn btn-link " role="button"> {{$area->description}}</a>
                            </td>
                            <td>
                                    <a  class="btn btn-link " role="button"> {{$area->price}}</a>
                                </td>
                        <td>
                            <form>
                                <button type="submit" class="btn btn-primary"
                                    formaction="/menu/{{$area->id}}/edit">Editar</button>
                            </form>
                        </td>
                        <td>
                            <form action="/menu/{{$area->id}}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
          
        </div>
    </div>
