@extends('layouts.app')


@section('content')
<div class="container">
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Correo</th>
                   
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>
            </thead>
            <tbody>


                 
                @foreach ($allUsers as $user)
                
                <tr>

                    <td>{{$user->id}}</td>
                    <td>
                        
                        <a class="btn btn-link " role="button"> {{$user->name}}</a>
                    </td>
                   
                        <td>
                            <a class="btn btn-link " role="button"> {{$user->email}}</a>
                        </td>

                   
                    <td>
                        <form>
                            <button type="submit" class="btn btn-primary" formaction="/user/{{$user->id}}/edit">Editar</button>
                        </form>
                    </td>
                    <td>
                        <form action="/user/{{$user->id}}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
                @endforeach 
            

            </tbody>
        </table>
        {{-- <form>
            <button type="submit" class="btn btn-primary" formaction="/user/create">Crear</button>
        </form> --}}
    </div>
</div>

@endsection