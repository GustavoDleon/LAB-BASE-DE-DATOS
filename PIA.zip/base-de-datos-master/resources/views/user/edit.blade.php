@extends('layouts.app')


@section('content')






<div class="container">
    <form class="form-horizontal col-sm-12" action="/user/{{$user->id}}" method="post" enctype="multipart/form-data">
        @csrf
        @method('PUT')
        <div class="form-group row">
            <label for="text" class="col-4 col-form-label">Nombre</label>
            <div class="col-8">
                <input id="name" name="name" type="text" value="{{$user->name}}" class="form-control" required="required">
            </div>
        </div>

        <div class="form-group row">
            <label for="text" class="col-4 col-form-label">Correo</label>
            <div class="col-8">
                <input id="name" name="email" type="text" value="{{$user->email}}" class="form-control" required="required">
            </div>
        </div>

        <div class="form-group row">
            <div class="offset-4 col-8">
                <button name="submit" type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </div>
    </form>
</div>



@endsection