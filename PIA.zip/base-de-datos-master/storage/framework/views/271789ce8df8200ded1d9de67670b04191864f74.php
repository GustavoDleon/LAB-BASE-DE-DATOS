<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<form>
        <button type="submit"  formaction="/menu">Lista de platillos </button>
     
    </form>
<form action="/menu" method="POST" > 
    <?php echo csrf_field(); ?>
    <br >
    <br>
        <div class="container">
  <div class="form-group row">
    <label class="col-4 col-form-label" for="name">Nombre del platillo</label> 
    <div class="col-8">
      <input id="name" name="name" type="text" class="form-control">
    </div>
  </div>
  <br>
  <div class="form-group row">
    <label for="description" class="col-4 col-form-label">Descripción del platillo</label> 
    <div class="col-8">
      <input id="description" name="description" type="text" class="form-control">
    </div>
  </div>
  <br>
  <div class="form-group row">
    <label for="price" class="col-4 col-form-label">$ Precio</label> 
    <div class="col-8">
      <input id="price" name="price" type="text" class="form-control" required pattern="[0-9]+">
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">Guardar</button>
    </div>
  </div>
        </div>
</form>
