<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Correo</th>
                   
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>
            </thead>
            <tbody>


                 
                <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <tr>

                    <td><?php echo e($user->id); ?></td>
                    <td>
                        
                        <a class="btn btn-link " role="button"> <?php echo e($user->name); ?></a>
                    </td>
                   
                        <td>
                            <a class="btn btn-link " role="button"> <?php echo e($user->email); ?></a>
                        </td>

                   
                    <td>
                        <form>
                            <button type="submit" class="btn btn-primary" formaction="/user/<?php echo e($user->id); ?>/edit">Editar</button>
                        </form>
                    </td>
                    <td>
                        <form action="/user/<?php echo e($user->id); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            

            </tbody>
        </table>
        
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>